@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo 请先安装 Node.js 22.13 或更新版本：https://nodejs.org/
  pause
  exit /b 1
)
if not exist dist\index.html (
  call npm ci --no-audit --no-fund
  if errorlevel 1 exit /b 1
  call npm run build
  if errorlevel 1 exit /b 1
)
node scripts\serve.mjs
pause
