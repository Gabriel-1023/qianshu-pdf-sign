import { defineConfig } from 'vite';
import { cpSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

export default defineConfig({
  base: './',
  plugins: [{
    name: 'local-pdf-assets',
    closeBundle() {
      for (const folder of ['cmaps', 'standard_fonts', 'wasm']) {
        cpSync(`node_modules/pdfjs-dist/${folder}`, `dist/pdf-assets/${folder}`, { recursive: true });
      }
      const notices = [
        ['PDF.js', 'pdfjs-dist/LICENSE'], ['pdf-lib', 'pdf-lib/LICENSE.md'],
        ['@pdf-lib/standard-fonts', '@pdf-lib/standard-fonts/LICENSE.md'],
        ['@pdf-lib/upng', '@pdf-lib/upng/LICENSE'], ['pako', 'pako/LICENSE'], ['tslib', 'tslib/LICENSE.txt'],
        ['fflate', 'fflate/LICENSE'],
      ].map(([name, path]) => `\n${name}\n${'='.repeat(60)}\n${readFileSync(`node_modules/${path}`, 'utf8')}`).join('\n');
      writeFileSync('dist/THIRD-PARTY-LICENSES.txt', notices);
    },
    configureServer(server) {
      server.middlewares.use('/pdf-assets', async (req, res, next) => {
        const { createReadStream, existsSync } = await import('node:fs');
        const { resolve, sep } = await import('node:path');
        const root = resolve('node_modules/pdfjs-dist');
        let file;
        try { file = resolve(root, '.' + decodeURIComponent(req.url.split('?')[0])); }
        catch { res.statusCode = 400; res.end(); return; }
        if (!file.startsWith(root + sep) || !existsSync(file)) return next();
        res.setHeader('Content-Type', file.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream');
        createReadStream(file).pipe(res);
      });
    },
  }],
  build: {
    target: 'es2022', chunkSizeWarningLimit: 1600,
    rollupOptions: { input: {
      signature: resolve('index.html'),
      tools: resolve('tools/index.html'),
      images: resolve('pdf-to-images/index.html'),
      merge: resolve('pdf-merge/index.html'),
    } },
  },
  server: { port: 5173, strictPort: true },
});
