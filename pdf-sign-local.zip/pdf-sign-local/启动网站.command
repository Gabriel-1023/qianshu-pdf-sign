#!/bin/zsh
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "请先安装 Node.js 22.13 或更新版本：https://nodejs.org/"
  read -r "?按回车关闭…"
  exit 1
fi
if [ ! -f dist/index.html ]; then
  npm ci --no-audit --no-fund
  npm run build
fi
node scripts/serve.mjs
