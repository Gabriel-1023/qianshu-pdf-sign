import test from 'node:test';
import assert from 'node:assert/strict';
import { PDFDocument, StandardFonts, degrees, rgb } from 'pdf-lib';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { resolve } from 'node:path';
import { mergePdfFiles, moveItem, pdfFilename } from '../src/pdf-merge.js';

async function fixture(label, count, rotation = 0, withForm = false) {
  const pdf = await PDFDocument.create(), font = await pdf.embedFont(StandardFonts.Helvetica);
  for (let i = 1; i <= count; i++) {
    const page = pdf.addPage([300, 400]); page.setRotation(degrees(rotation)); page.setCropBox(10, 20, 280, 360);
    page.drawText(`${label}-${i}`, { font, size: 20, x: 40, y: 320, color: rgb(.1, .3, .2) });
    if (withForm && i === 1) {
      const field = pdf.getForm().createTextField('same-field-name'); field.setText(label);
      field.addToPage(page, { x: 40, y: 180, width: 180, height: 30, font });
    }
  }
  const bytes = await pdf.save(); return { name: `${label}.pdf`, count, read: async () => bytes.slice() };
}
test('合并按拖动后的顺序写入所有页，保留可选文字、旋转和裁剪，固化同名表单', async () => {
  const a = await fixture('A', 2, 0, true), b = await fixture('B', 1, 90, true), c = await fixture('C', 1, 180);
  const entries = moveItem([a, b, c], 2, 0), progress = [];
  const result = await mergePdfFiles(entries, { onProgress: step => progress.push(step.done) });
  assert.equal(result.count, 4);
  const parsed = await PDFDocument.load(result.bytes);
  assert.deepEqual(parsed.getPages().map(page => page.getRotation().angle), [180, 0, 0, 90]);
  assert.deepEqual(parsed.getPages().map(page => page.getCropBox()), Array(4).fill({ x: 10, y: 20, width: 280, height: 360 }));
  assert.equal(parsed.getForm().getFields().length, 0, '没有丢失引用或互相串值的表单字段');
  const task = getDocument({ data: result.bytes.slice(), standardFontDataUrl: resolve('node_modules/pdfjs-dist/standard_fonts') + '/' });
  try {
    const pdf = await task.promise;
    const labels = [];
    for (let n = 1; n <= 4; n++) {
      const page = await pdf.getPage(n);
      labels.push((await page.getTextContent()).items.map(item => item.str).join(' '));
      assert.equal((await page.getAnnotations()).filter(item => item.subtype === 'Widget').length, 0);
    }
    for (const [index, label] of ['C-1', 'A-1', 'A-2', 'B-1'].entries()) assert.ok(labels[index].includes(label));
    assert.ok(labels[1].endsWith('A') && labels[3].endsWith('B'), '两个同名字段均保留自己的显示值');
  } finally { await task.destroy(); }
  assert.equal(progress.at(-1), 4);
});
test('合并支持取消并拒绝单文件、损坏文件与超额页数', async () => {
  const entry = await fixture('A', 1);
  await assert.rejects(mergePdfFiles([entry]), /至少添加两份/);
  await assert.rejects(mergePdfFiles([entry, { ...entry, read: async () => new Uint8Array([1, 2]) }]));
  await assert.rejects(mergePdfFiles([{ ...entry, count: 1001 }, entry]), /1000/);
  const controller = new AbortController();
  await assert.rejects(mergePdfFiles([entry, entry], { signal: controller.signal, onProgress(step) { if (step.done) controller.abort(); } }), { name: 'AbortError' });
  assert.equal((await PDFDocument.load(await entry.read())).getPageCount(), 1);
  assert.deepEqual(moveItem(['a', 'b', 'c'], 0, 2), ['b', 'c', 'a']);
  assert.deepEqual(moveItem(['a', 'b'], 0, -1), ['a', 'b']);
  assert.equal(pdfFilename('../test.pdf'), '_test.pdf');
  assert.equal(pdfFilename('NUL'), '_NUL.pdf');
});
