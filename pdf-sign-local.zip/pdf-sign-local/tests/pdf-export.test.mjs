import test from 'node:test';
import assert from 'node:assert/strict';
import { PDFDocument, StandardFonts, degrees } from 'pdf-lib';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createCanvas } from '@napi-rs/canvas';
import { clampPlacement, placementToPdf, resizePlacement } from '../src/geometry.js';
import { resolve } from 'node:path';
import { flattenPdf } from '../src/pdf-export.js';

const standardFontDataUrl = resolve('node_modules/pdfjs-dist/standard_fonts') + '/';

test('签名导出在 0/90/180/270 度裁剪页上与可见预览位置一致，并保留原文', async () => {
  const original = await PDFDocument.create();
  const font = await original.embedFont(StandardFonts.Helvetica);
  for (const angle of [0, 90, 180, 270]) {
    const page = original.addPage([595, 842]);
    page.setCropBox(31, 57, 510, 720);
    page.setRotation(degrees(angle));
    page.drawText('Original text remains selectable', { x: 55, y: 700, size: 12, font });
  }
  const source = await original.save();
  const preview = await getDocument({ data: source.slice(), standardFontDataUrl }).promise;
  const output = await PDFDocument.load(source);
  const marker = createCanvas(80, 40);
  const markerContext = marker.getContext('2d');
  for (const [x, y, color] of [[0, 0, '#ff0000'], [40, 0, '#00ff00'], [0, 20, '#0000ff'], [40, 20, '#000000']]) {
    markerContext.fillStyle = color; markerContext.fillRect(x, y, 40, 20);
  }
  const image = await output.embedPng(marker.toBuffer('image/png'));
  const item = { x: .2, y: .4, w: .3, h: .13 };
  for (let n = 1; n <= 4; n++) {
    const viewport = (await preview.getPage(n)).getViewport({ scale: 1 });
    const { angle, ...options } = placementToPdf(item, viewport);
    output.getPage(n - 1).drawImage(image, { ...options, rotate: degrees(angle) });
  }
  const bytes = await output.save();
  const reopened = await PDFDocument.load(bytes);
  assert.equal(reopened.getPageCount(), 4);
  const signed = await getDocument({ data: bytes, standardFontDataUrl }).promise;
  try {
    for (let n = 1; n <= 4; n++) {
      const page = await signed.getPage(n);
      const viewport = page.getViewport({ scale: 1 });
      const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
      const context = canvas.getContext('2d');
      await page.render({ canvasContext: context, viewport }).promise;
      for (const [u, v, expected] of [[.25, .25, [255, 0, 0]], [.75, .25, [0, 255, 0]], [.25, .75, [0, 0, 255]], [.75, .75, [0, 0, 0]]]) {
        const x = Math.floor((item.x + item.w * u) * viewport.width);
        const y = Math.floor((item.y + item.h * v) * viewport.height);
        const actual = [...context.getImageData(x, y, 1, 1).data].slice(0, 3);
        assert.deepEqual(actual, expected, `第 ${n} 页的签名方向和位置`);
      }
      assert.ok((await page.getTextContent()).items.map(item => item.str).join(' ').includes('Original text remains selectable'));
      assert.equal(reopened.getPage(n - 1).getRotation().angle, (n - 1) * 90);
      assert.deepEqual(reopened.getPage(n - 1).getCropBox(), { x: 31, y: 57, width: 510, height: 720 });
    }
  } finally { await preview.loadingTask.destroy(); await signed.loadingTask.destroy(); }
});

test('手机尺寸下缩放保持比例，签名不能超出页面边界', () => {
  const item = { x: .63, y: .82, w: .25, h: .08 };
  const enlarged = resizePlacement(item, 500, 500, 328, 464);
  assert.ok(enlarged.x + enlarged.w <= 1 + Number.EPSILON);
  assert.ok(enlarged.y + enlarged.h <= 1 + Number.EPSILON);
  assert.ok(Math.abs(enlarged.w / enlarged.h - item.w / item.h) < 1e-9);
  const shrunk = resizePlacement(item, -10000, -10000, 328, 464);
  assert.ok(shrunk.w >= .035 && shrunk.h >= .005);
  assert.ok(Math.abs(shrunk.w / shrunk.h - item.w / item.h) < 1e-9);
  assert.deepEqual(clampPlacement({ x: -1, y: 2, w: .25, h: .08 }), { x: 0, y: .92, w: .25, h: .08 });
});

test('合并下载每页只有一张完整页面图片，原文字及独立签名对象已移除', async () => {
  const original = await PDFDocument.create();
  const font = await original.embedFont(StandardFonts.Helvetica);
  const page = original.addPage([300, 450]);
  page.setCropBox(20, 30, 250, 380); page.setRotation(degrees(90));
  page.drawText('Original page content', { x: 50, y: 340, font, size: 12 });
  const imageCanvas = createCanvas(60, 30);
  const ctx = imageCanvas.getContext('2d'); ctx.fillStyle = '#245c47'; ctx.fillRect(0, 0, 60, 30);
  page.drawImage(await original.embedPng(imageCanvas.toBuffer('image/png')), { x: 100, y: 180, width: 60, height: 30 });
  const progress = [];
  const bytes = await flattenPdf(await original.save(), {
    documentOptions: { standardFontDataUrl },
    createCanvas: () => createCanvas(1, 1),
    encodeCanvas: canvas => canvas.toBuffer('image/jpeg', 96),
    onProgress: (page, total) => progress.push([page, total]),
  });
  assert.deepEqual(progress, [[1, 1]]);
  const result = await PDFDocument.load(bytes);
  assert.deepEqual(result.getPage(0).getSize(), { width: 380, height: 250 });
  const parsed = await getDocument({ data: bytes, standardFontDataUrl }).promise;
  try {
    const output = await parsed.getPage(1);
    assert.equal((await output.getTextContent()).items.length, 0, '没有残留的可选文字层');
    const operators = await output.getOperatorList();
    const { OPS } = await import('pdfjs-dist/legacy/build/pdf.mjs');
    assert.equal(operators.fnArray.filter(op => op === OPS.paintImageXObject).length, 1, '没有独立的签名图片对象');
    assert.equal((await output.getAnnotations()).length, 0);
    const viewport = output.getViewport({ scale: 1 });
    const canvas = createCanvas(380, 250);
    const context = canvas.getContext('2d');
    await output.render({ canvasContext: context, viewport }).promise;
    const [r, g, b] = context.getImageData(160, 110, 1, 1).data;
    assert.ok(g > r && g > b, '合并后仍能在预期位置看到签名');
  } finally { await parsed.loadingTask.destroy(); }
});
