import test from 'node:test';
import assert from 'node:assert/strict';
import { PDFDocument, rgb, degrees } from 'pdf-lib';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { unzipSync } from 'fflate';
import { resolve } from 'node:path';
import { parsePageRange, imageViewport, archiveFolder, convertPdfBatch } from '../src/pdf-images.js';

const documentOptions = { standardFontDataUrl: resolve('node_modules/pdfjs-dist/standard_fonts') + '/' };
const create = () => createCanvas(1, 1);
const encodeCanvas = (canvas, mime) => new Uint8Array(canvas.toBuffer(mime));
async function fixture() {
  const pdf = await PDFDocument.create();
  for (const angle of [0, 90, 180]) {
    const page = pdf.addPage([300, 400]); page.setCropBox(20, 30, 200, 300); page.setRotation(degrees(angle));
    page.drawRectangle({ x: 20, y: 180, width: 100, height: 150, color: rgb(1, 0, 0) });
    page.drawRectangle({ x: 120, y: 180, width: 100, height: 150, color: rgb(0, 1, 0) });
    page.drawRectangle({ x: 20, y: 30, width: 100, height: 150, color: rgb(0, 0, 1) });
    // Bottom right remains transparent in PDF and must render white in each image.
  }
  return pdf.save();
}
test('页码选择去重排序，拒绝越界与歧义输入，允许中文逗号', () => {
  assert.deepEqual(parsePageRange('', 5), [1, 2, 3, 4, 5]);
  assert.deepEqual(parsePageRange('5，1, 3-4, 3', 5), [1, 3, 4, 5]);
  for (const value of ['0', '6', '3-1', '1,', '-1', 'a', '1.5', '1-99999999999']) assert.throws(() => parsePageRange(value, 5));
});
test('巨型页面自动降采样，保持长宽比和画布尺寸上限', () => {
  const page = { getViewport: ({ scale }) => ({ width: 40000 * scale, height: 20000 * scale }) };
  const size = imageViewport(page, 300);
  assert.equal(size.limited, true);
  assert.ok(size.width * size.height <= 12000000);
  assert.ok(Math.max(size.width, size.height) <= 8192);
  assert.ok(Math.abs(size.width / size.height - 2) < .001);
  assert.equal(archiveFolder('../a\\b:中文.pdf', 0), '01__a_b_中文');
});
test('多个 PDF 的选定页进入独立 ZIP 文件夹，旋转和裁剪正确，PNG / JPG 可解码', async () => {
  const bytes = await fixture();
  const progress = [];
  for (const format of ['png', 'jpeg']) {
    const result = await convertPdfBatch([
      { name: '同名.pdf', pages: [1, 2], read: async () => bytes.slice() },
      { name: '同名.pdf', pages: [3], read: async () => bytes.slice() },
    ], { format, dpi: 72, documentOptions, createCanvas: create, encodeCanvas, onProgress: value => progress.push(value.done) });
    assert.equal(result.count, 3); assert.equal(result.documents.length, 2);
    const archive = unzipSync(new Uint8Array(await result.blob.arrayBuffer()));
    const ext = format === 'jpeg' ? 'jpg' : 'png';
    assert.deepEqual(Object.keys(archive), [`01_同名/page-001.${ext}`, `01_同名/page-002.${ext}`, `02_同名/page-003.${ext}`]);
    for (const [path, data] of Object.entries(archive)) {
      const image = await loadImage(data);
      const rotated = path.includes('002');
      assert.equal(image.width, rotated ? 300 : 200); assert.equal(image.height, rotated ? 200 : 300);
      const canvas = createCanvas(image.width, image.height); const ctx = canvas.getContext('2d'); ctx.drawImage(image, 0, 0);
      const color = (x, y) => [...ctx.getImageData(x, y, 1, 1).data];
      const sample = rotated ? color(225, 50) : path.includes('003') ? color(150, 225) : color(50, 75);
      assert.ok(sample[0] > 240 && sample[1] < 10 && sample[2] < 10 && sample[3] === 255, `${path} 红色象限位置正确`);
      const white = rotated ? color(75, 150) : path.includes('003') ? color(50, 75) : color(150, 225);
      assert.ok(white.every(channel => channel > 245), `${path} 空白背景为白色`);
    }
  }
  assert.ok(progress.includes(3));
});
test('超出输出预算、损坏的 PDF 与取消均不产生伪成功结果', async () => {
  const bytes = await fixture();
  const entry = { name: 'sample.pdf', pages: [1, 2, 3], read: async () => bytes.slice() };
  const options = { dpi: 72, documentOptions, createCanvas: create, encodeCanvas };
  await assert.rejects(convertPdfBatch([entry], { ...options, maxOutputBytes: 50 }), /超过 128 MB/);
  await assert.rejects(convertPdfBatch([{ ...entry, read: async () => new Uint8Array([0, 1, 2]) }], options));
  const controller = new AbortController();
  let emitted = 0;
  await assert.rejects(convertPdfBatch([entry], { ...options, signal: controller.signal, onImage() { emitted++; controller.abort(); } }));
  assert.equal(emitted, 1, '取消后停止处理后续页面');
  const preCancelled = new AbortController(); preCancelled.abort();
  await assert.rejects(convertPdfBatch([entry], { ...options, signal: preCancelled.signal }), { name: 'AbortError' });
  const source = await getDocument({ data: bytes.slice(), ...documentOptions }).promise;
  assert.equal(source.numPages, 3, '原 PDF 未被修改'); await source.loadingTask.destroy();
});
