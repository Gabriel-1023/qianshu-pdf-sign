import test from 'node:test';
import assert from 'node:assert/strict';
import { createCanvas } from '@napi-rs/canvas';
import { SignaturePad } from '../src/signature-pad.js';

test('手写区域阻止触摸默认菜单，触摸结束后仍可继续书写', () => {
  const originalWindow = globalThis.window;
  const originalObserver = globalThis.ResizeObserver;
  let clearedSelections = 0;
  globalThis.window = { devicePixelRatio: 1, getSelection: () => ({ removeAllRanges() { clearedSelections++; } }) };
  globalThis.ResizeObserver = class { observe() {} };
  const surface = createCanvas(320, 240);
  class TestCanvas extends EventTarget {
    parentElement = {};
    registrations = new Map();
    get width() { return surface.width; }
    set width(value) { surface.width = value; }
    get height() { return surface.height; }
    set height(value) { surface.height = value; }
    getContext() { return surface.getContext('2d'); }
    getBoundingClientRect() { return { left: 0, top: 0, width: 320, height: 240 }; }
    setPointerCapture() {}
    addEventListener(type, listener, options) { this.registrations.set(type, options); super.addEventListener(type, listener, options); }
  }
  const canvas = new TestCanvas();
  const counts = [];
  try {
    const pad = new SignaturePad(canvas, count => counts.push(count)); pad.resize();
    for (const type of ['touchstart', 'touchmove', 'contextmenu', 'selectstart', 'dragstart']) {
      const event = new Event(type, { cancelable: true });
      canvas.dispatchEvent(event);
      assert.equal(event.defaultPrevented, true, `${type} 不触发浏览器原生行为`);
    }
    assert.equal(canvas.registrations.get('touchstart').passive, false);
    assert.equal(canvas.registrations.get('touchmove').passive, false);
    const pointer = (type, id, x, y) => canvas.dispatchEvent(Object.assign(new Event(type, { cancelable: true }), { pointerId: id, pointerType: 'touch', clientX: x, clientY: y }));
    pointer('pointerdown', 1, 40, 70); pointer('pointermove', 1, 140, 80); pointer('pointerup', 1, 140, 80);
    pointer('pointerdown', 2, 50, 90); pointer('pointermove', 2, 170, 120); pointer('pointercancel', 2, 170, 120);
    assert.equal(pad.strokes.length, 2);
    assert.equal(pad.active, null);
    assert.ok(pad.strokes.every(stroke => stroke.points.length >= 2));
    assert.ok(clearedSelections >= 3);
    assert.equal(counts.at(-1), 2);
  } finally { globalThis.window = originalWindow; globalThis.ResizeObserver = originalObserver; }
});
