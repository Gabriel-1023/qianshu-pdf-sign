# 一方工具 · 本地 PDF 工具箱

工具导航：[打开一方工具](https://gabriel-1023.github.io/qianshu-pdf-sign/tools/)。发布仓库：[Gabriel-1023/qianshu-pdf-sign](https://github.com/Gabriel-1023/qianshu-pdf-sign)。

| 页面 | 线上地址 | 本地地址 |
| --- | --- | --- |
| 工具导航 | https://gabriel-1023.github.io/qianshu-pdf-sign/tools/ | http://localhost:4173/tools/ |
| PDF 手写签署 | https://gabriel-1023.github.io/qianshu-pdf-sign/ | http://localhost:4173/ |
| PDF 批量转图片 | https://gabriel-1023.github.io/qianshu-pdf-sign/pdf-to-images/ | http://localhost:4173/pdf-to-images/ |
| PDF 顺序合并 | https://gabriel-1023.github.io/qianshu-pdf-sign/pdf-merge/ | http://localhost:4173/pdf-merge/ |

GitHub 仓库通过 Actions 解压预构建的 `pdf-sign-github-pages.zip` 并发布到 Pages；完整源码位于本项目目录和 `pdf-sign-local.zip` 交付包中。

一个适配电脑和手机的小网站：选择 PDF，在画布中手写签名，拖动、缩放到合适的位置，再下载签好的 PDF。所有文件处理都在访问者的浏览器中完成，不上传文档、不保存签名，不依赖在线 API 或 CDN。

现在包含三个工具。各工具使用独立的静态 HTML 入口，共享依赖；原签署网址保持不变。今后可按同样方式新增工具并链接到 `tools/index.html`，不用增加服务器。

## PDF 批量转图片

1. 添加多份 PDF，或先点击「用示例试试」。可继续添加、移除、清空文件。
2. 每份 PDF 可填写页码，例如 `1, 3-5`；留空表示全部，按原页码排序并去重。
3. 选择 PNG（无损）或 JPG（约 92% 质量），以及 72 / 150 / 200 / 300 DPI。
4. 转换完成后可预览并单独下载前 6 张图片，或一次下载包含全部图片的 ZIP。

ZIP 按 `01_原文件名/page-001.png` 分组，即使文件同名也不会覆盖。每页使用白色背景，保留 PDF 可见裁剪与旋转方向。最多 20 份、单份 100 MB、合计 200 MB、500 页；生成结果上限 128 MB。逐页释放画布，超大页保持比例缩至 1200 万像素以内且单边不超过 8192。手机建议使用 150 DPI、JPG 并分批处理。可取消处理；损坏或加密文件会显示原因。

## PDF 顺序合并

1. 添加至少两份 PDF，可重复添加同名文件，最多 30 份、单份 100 MB、合计 200 MB / 1000 页。
2. 按住左侧手柄拖动调整顺序，手机同样支持；也可使用上下箭头。键盘聚焦手柄后可按上下方向键调序。
3. 设置文件名，点击「合并 PDF」，完成后下载。页面严格按列表从上到下追加。

直接复制页面，保留文字、图像、页面尺寸、裁剪框和旋转，不对原页进行栅格化。表单按现有外观固化，以避免同名字段互相覆盖；缺失表单外观时会报错。文档目录书签、附件与证书数字签名不作为合并内容保留。带密码的文件需先解除保护。手机建议合计小于 50 MB。原文件不会被覆盖，合并可取消。

## 直接运行

安装 **Node.js 22.13 或更新版本**。交付包已经包含构建好的 `dist/`，不需要安装 npm 依赖即可启动：

```sh
cd pdf-sign-local
node scripts/serve.mjs
```

电脑访问 **http://localhost:4173**。macOS 可双击「启动网站.command」，Windows 可双击「启动网站.bat」。终端需要保持打开，按 `Ctrl+C` 停止。

手机连接与电脑相同的 Wi-Fi，在手机 Safari 或 Chrome 打开终端显示的局域网地址，例如 `http://192.168.1.10:4173`。手机中的 `localhost` 指向手机本身，请使用电脑的局域网 IP。若无法连接，检查是否在同一网络以及防火墙是否允许 Node.js 访问局域网。

服务仅提供静态网页，上传、书写及导出不向服务器发送文件。依赖和字体资源均已打包，本机启动后无需互联网。

更换端口：macOS / Linux 使用 `PORT=8080 npm start`；Windows PowerShell 使用 `$env:PORT=8080; npm start`。

## 使用方式

1. 点击「上传 PDF 文件」，或将 PDF 拖到网页上。也可先打开内置示例。
2. 点击「创建我的签名」，用鼠标、手指或触控笔签名，支持三种颜色、三种粗细、撤销和清空。
3. 点击「使用这个签名」，签名会自动放到当前 PDF 页；也可先写签名，再选文件后点击「放到当前页」。
4. 拖动签名，拉动右下角圆点等比例缩放。点击「确定位置」取消选择；点击签名可重新调整。支持复制和删除，电脑上也可用方向键微调、Delete 删除，Shift+方向键加快移动。
5. 多页 PDF 用底部箭头翻页，再次点击「放到当前页」即可添加到其他页。重写签名不会改变已经放置的签名。
6. 选择下载方式，再点击「完成并下载 PDF」。手机 Safari 如打开了文件预览，可通过系统分享菜单选择「存储到文件」。

两种下载方式：

| 方式 | 结果 | 签名是否可单独提取 |
| --- | --- | --- |
| 保留原文（默认） | 保留原页、文字和清晰度，文件名为 `原文件名_已签名.pdf` | 签名作为透明图片对象嵌入，可以被 PDF 编辑器提取 |
| 合并为图片 | 每页与签名先渲染为一张不透明图片，再生成 PDF，文件名为 `原文件名_已签名_合并图片.pdf` | 没有独立签名对象，但仍可通过截图或裁剪整页图片获得签名 |

「合并为图片」采用约 144 dpi 的页面渲染，超大页面会限制到 600 万像素。文字不可选中，链接、书签、表单和原数字签名不保留，文件可能变大，处理也需要更长时间。它减少直接提取透明签名的便利，不提供防复制或防篡改保证。

刷新或关闭页面会清除文件和签名，请先下载。选择另一份 PDF 会清除当前文件上的放置记录，并保留当前签名供继续使用。原始 PDF 不会被覆盖。

## 修改和重新构建

```sh
npm ci
npm run dev
```

开发地址为 http://localhost:5173，同样支持局域网手机访问。编辑 `src/` 后重新构建正式版：

```sh
npm test
npm run build
npm start
```

`dist/` 是完全自包含的静态网站，可复制到 Nginx、NAS 静态网站目录或任意 HTTP 静态服务器。不支持直接双击 `index.html` 以 `file://` 方式运行，因为 PDF Worker 需要 HTTP 服务。

## Docker 部署（可选）

```sh
docker compose up -d --build
```

访问 http://localhost:8080，或手机访问 `http://电脑IP:8080`。停止：`docker compose down`。

## 能力与范围

- 支持多页、横向、旋转页及有裁剪框的 PDF；签名使用 PDF.js 的页面坐标转换后写入原页。
- 默认保留原有页面和文字，签名以透明 PNG 嵌入；也可选「合并为图片」去除独立签名对象。
- 支持手机触摸绘制、拖动及缩放；文件只在内存中处理，不写入浏览器本地存储。
- 最大文件 100 MB，建议小于 50 MB；大型扫描件在手机上的处理速度取决于设备内存。
- 加密 PDF 需要先移除密码保护。此工具添加手写签名图像，不生成带证书的数字签名，也不验证已有数字签名。
- 推荐使用较新版本 Safari、Chrome、Edge 或 Firefox。

## 项目结构

```text
src/main.js           文件加载、预览、放置交互、导出与示例
src/signature-pad.js  Pointer Events 画布、撤销与透明签名裁剪
src/geometry.js       坐标转换与边界、等比例缩放
src/pdf-export.js     将签名与整页合并后导出
src/style.css         桌面和手机样式
src/batch-images.js  批量转图页面与队列
src/pdf-images.js    逐页渲染、页码解析和 ZIP 打包
src/merge.js         PDF 合并页面与触摸拖动排序
src/pdf-merge.js     按顺序复制页面与表单固化
src/toolbox.css      导航页和新工具共享样式
tools/index.html    工具导航入口
pdf-to-images/      批量转换静态入口
pdf-merge/          合并静态入口
scripts/serve.mjs     无运行依赖的本地静态服务器
tests/                PDF 坐标与导出验证
dist/                 可直接部署的构建结果
```

核心依赖：[PDF.js](https://mozilla.github.io/pdf.js/)（预览、图片渲染和坐标转换）、[pdf-lib](https://pdf-lib.js.org/)（写入签名、合并 PDF）、[fflate](https://github.com/101arrowz/fflate)（ZIP 打包），构建工具为 Vite。依赖的许可证汇总在 `dist/THIRD-PARTY-LICENSES.txt`。
