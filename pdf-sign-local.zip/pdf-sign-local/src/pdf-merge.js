import { PDFDocument } from 'pdf-lib';

export const MAX_MERGE_PAGES = 1000;
function checkAbort(signal) { if (signal?.aborted) throw new DOMException('已取消合并', 'AbortError'); }
export function moveItem(items, from, to) {
  if (from < 0 || from >= items.length || to < 0 || to >= items.length || from === to) return [...items];
  const result = [...items]; const [item] = result.splice(from, 1); result.splice(to, 0, item); return result;
}
export function pdfFilename(value) {
  const base = value.replace(/\.pdf$/i, '').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g, '_').replace(/^[. ]+|[. ]+$/g, '').slice(0, 80) || '合并文档';
  return `${/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(base) ? '_' : ''}${base}.pdf`;
}
export async function mergePdfFiles(entries, { signal, onProgress = () => {} } = {}) {
  if (entries.length < 2) throw new Error('请至少添加两份 PDF');
  checkAbort(signal);
  const output = await PDFDocument.create();
  let done = 0;
  const total = entries.reduce((sum, entry) => sum + entry.count, 0);
  if (total > MAX_MERGE_PAGES) throw new Error('每批最多合并 1000 页，请减少文件后重试');
  for (const entry of entries) {
    checkAbort(signal);
    onProgress({ file: entry.name, done, total, stage: 'opening' });
    const bytes = await entry.read(); checkAbort(signal);
    const source = await PDFDocument.load(bytes, { updateMetadata: false });
    checkAbort(signal);
    if (output.getPageCount() + source.getPageCount() > MAX_MERGE_PAGES) throw new Error('每批最多合并 1000 页');
    const form = source.getForm();
    if (form.getFields().length) {
      try { form.flatten({ updateFieldAppearances: false }); }
      catch { throw new Error(`${entry.name} 的表单缺少可用外观，请先用 PDF 阅读器打印为 PDF 后再合并`); }
    }
    for (let start = 0; start < source.getPageCount(); start += 10) {
      checkAbort(signal);
      const indices = Array.from({ length: Math.min(10, source.getPageCount() - start) }, (_, i) => start + i);
      const pages = await output.copyPages(source, indices);
      for (const page of pages) output.addPage(page);
      done += pages.length;
      onProgress({ file: entry.name, done, total, stage: 'copying' });
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
  checkAbort(signal); onProgress({ file: '', done, total, stage: 'saving' });
  const bytes = await output.save({ objectsPerTick: 30 });
  checkAbort(signal);
  return { bytes, count: output.getPageCount() };
}
