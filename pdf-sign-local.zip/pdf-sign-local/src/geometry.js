export const clamp = (value, min, max) => Math.max(min, Math.min(value, max));

// Placements are fractions of the visible PDF viewport, independent of screen size.
export function clampPlacement(item) {
  item.w = clamp(item.w, 0.035, 1);
  item.h = clamp(item.h, 0.005, 1);
  item.x = clamp(item.x, 0, 1 - item.w);
  item.y = clamp(item.y, 0, 1 - item.h);
  return item;
}

// Use the PDF.js inverse viewport transform to support CropBox and 0/90/180/270° pages.
export function placementToPdf(item, viewport) {
  const x = item.x * viewport.width;
  const y = item.y * viewport.height;
  const w = item.w * viewport.width;
  const h = item.h * viewport.height;
  const bottomLeft = viewport.convertToPdfPoint(x, y + h);
  const bottomRight = viewport.convertToPdfPoint(x + w, y + h);
  const topLeft = viewport.convertToPdfPoint(x, y);
  const dx = bottomRight[0] - bottomLeft[0];
  const dy = bottomRight[1] - bottomLeft[1];
  return {
    x: bottomLeft[0], y: bottomLeft[1],
    width: Math.hypot(dx, dy),
    height: Math.hypot(topLeft[0] - bottomLeft[0], topLeft[1] - bottomLeft[1]),
    angle: Math.atan2(dy, dx) * 180 / Math.PI,
  };
}

export function resizePlacement(initial, dx, dy, pageWidth, pageHeight) {
  const width = initial.w * pageWidth;
  const height = initial.h * pageHeight;
  const factor = (dx * width + dy * height) / (width * width + height * height) + 1;
  const maximum = Math.min((1 - initial.x) / initial.w, (1 - initial.y) / initial.h);
  const minimum = Math.min(maximum, Math.max(0.035 / initial.w, 0.005 / initial.h));
  const scale = clamp(factor, minimum, maximum);
  return { ...initial, w: initial.w * scale, h: initial.h * scale };
}
