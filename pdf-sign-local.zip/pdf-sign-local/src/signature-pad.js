export class SignaturePad {
  constructor(canvas, onChange) {
    this.canvas = canvas;
    this.onChange = onChange;
    this.strokes = [];
    this.active = null;
    this.pointerId = null;
    this.color = '#202725';
    this.width = 3;
    this.baseWidth = 0;
    // iOS can start text selection or its long-press callout even with Pointer
    // Events. Cancel the native touch gesture on the canvas before that happens.
    const preventNativeGesture = event => { if (event.cancelable) event.preventDefault(); };
    canvas.addEventListener('touchstart', event => {
      window.getSelection()?.removeAllRanges();
      preventNativeGesture(event);
    }, { passive: false });
    canvas.addEventListener('touchmove', preventNativeGesture, { passive: false });
    canvas.addEventListener('contextmenu', preventNativeGesture);
    canvas.addEventListener('selectstart', preventNativeGesture);
    canvas.addEventListener('dragstart', preventNativeGesture);
    canvas.addEventListener('pointerdown', e => this.start(e));
    canvas.addEventListener('pointermove', e => this.move(e));
    canvas.addEventListener('pointerup', e => this.end(e));
    canvas.addEventListener('pointercancel', e => this.end(e));
    canvas.addEventListener('lostpointercapture', e => this.end(e));
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(canvas.parentElement);
  }
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    if (!this.baseWidth) { this.baseWidth = rect.width; this.baseHeight = rect.height; }
    const ratio = Math.min(window.devicePixelRatio || 1, 3);
    this.canvas.width = Math.round(rect.width * ratio);
    this.canvas.height = Math.round(rect.height * ratio);
    this.scale = Math.min(rect.width / this.baseWidth, rect.height / this.baseHeight);
    this.offsetX = (rect.width - this.baseWidth * this.scale) / 2;
    this.offsetY = (rect.height - this.baseHeight * this.scale) / 2;
    this.ratio = ratio;
    this.redraw();
  }
  point(event) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left - this.offsetX) / this.scale,
      y: (event.clientY - rect.top - this.offsetY) / this.scale,
    };
  }
  start(event) {
    if (this.active || (event.pointerType === 'mouse' && event.button !== 0)) return;
    event.preventDefault();
    window.getSelection()?.removeAllRanges();
    this.pointerId = event.pointerId;
    this.canvas.setPointerCapture(event.pointerId);
    this.active = { color: this.color, width: this.width, points: [this.point(event)] };
    this.strokes.push(this.active);
    this.redraw();
    this.onChange(this.strokes.length);
  }
  move(event) {
    if (!this.active || event.pointerId !== this.pointerId) return;
    event.preventDefault();
    for (const point of event.getCoalescedEvents?.() || [event]) this.active.points.push(this.point(point));
    this.redraw();
  }
  end(event) {
    if (event.pointerId !== this.pointerId || !this.active) return;
    this.active = null;
    this.pointerId = null;
    this.onChange(this.strokes.length);
  }
  paint(ctx) {
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (const stroke of this.strokes) {
      const points = stroke.points;
      ctx.strokeStyle = ctx.fillStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      if (points.length === 1) {
        ctx.beginPath(); ctx.arc(points[0].x, points[0].y, stroke.width / 2, 0, Math.PI * 2); ctx.fill();
        continue;
      }
      ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length - 1; i++) {
        const next = points[i + 1];
        ctx.quadraticCurveTo(points[i].x, points[i].y, (points[i].x + next.x) / 2, (points[i].y + next.y) / 2);
      }
      const last = points.at(-1); ctx.lineTo(last.x, last.y); ctx.stroke();
    }
  }
  redraw() {
    if (!this.canvas.width || !this.ratio) return;
    const ctx = this.canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.setTransform(this.ratio * this.scale, 0, 0, this.ratio * this.scale, this.offsetX * this.ratio, this.offsetY * this.ratio);
    this.paint(ctx);
  }
  clear() { this.strokes = []; this.active = null; this.redraw(); this.onChange(0); }
  undo() { this.strokes.pop(); this.redraw(); this.onChange(this.strokes.length); }
  export() {
    if (!this.strokes.length) return null;
    const scale = 3;
    const full = document.createElement('canvas');
    full.width = Math.ceil(this.baseWidth * scale); full.height = Math.ceil(this.baseHeight * scale);
    const ctx = full.getContext('2d', { willReadFrequently: true });
    ctx.scale(scale, scale); this.paint(ctx);
    const { data } = ctx.getImageData(0, 0, full.width, full.height);
    let left = full.width, right = 0, top = full.height, bottom = 0;
    for (let y = 0; y < full.height; y++) for (let x = 0; x < full.width; x++) {
      if (data[(y * full.width + x) * 4 + 3] > 0) {
        left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
      }
    }
    if (left > right || top > bottom) return null;
    const padding = 10;
    const result = document.createElement('canvas');
    result.width = right - left + 1 + padding * 2; result.height = bottom - top + 1 + padding * 2;
    result.getContext('2d').drawImage(full, left, top, right - left + 1, bottom - top + 1, padding, padding, right - left + 1, bottom - top + 1);
    return { id: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`, dataUrl: result.toDataURL('image/png'), width: result.width, height: result.height };
  }
}
