import './style.css';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import workerUrl from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url';
import { PDFDocument, StandardFonts, rgb, degrees } from 'pdf-lib';
import { hydrateIcons, icon } from './icons.js';
import { clamp, clampPlacement, placementToPdf, resizePlacement } from './geometry.js';
import { SignaturePad } from './signature-pad.js';
import { flattenPdf } from './pdf-export.js';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
hydrateIcons();
const $ = id => document.getElementById(id);
const state = {
  pdf: null, bytes: null, name: '', fileSize: 0, page: 1, zoom: 1,
  pages: new Map(), placements: [], signature: null, selected: null,
  busy: false, rendering: false, generation: 0, renderTask: null, downloadUrl: null,
};
let toastTimer;
const pdfAssets = {
  cMapUrl: `${import.meta.env.BASE_URL}pdf-assets/cmaps/`, cMapPacked: true,
  standardFontDataUrl: `${import.meta.env.BASE_URL}pdf-assets/standard_fonts/`,
  wasmUrl: `${import.meta.env.BASE_URL}pdf-assets/wasm/`,
};
function toast(message, error = false) {
  clearTimeout(toastTimer);
  $('toast').textContent = message;
  $('toast').classList.toggle('error', error);
  $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, error ? 7000 : 4500);
}
function loading(show, message = '正在打开 PDF…') {
  $('loading-overlay').hidden = !show;
  $('loading-text').textContent = message;
}
function fileSize(size) { return size < 1024 * 1024 ? `${Math.max(1, Math.round(size / 1024))} KB` : `${(size / 1024 / 1024).toFixed(1)} MB`; }
function updateUI() {
  const hasFile = !!state.pdf;
  const locked = state.busy || state.rendering;
  $('empty-state').hidden = hasFile;
  $('page-area').hidden = !hasFile;
  $('file-details').hidden = !hasFile;
  $('upload-title').textContent = hasFile ? '更换 PDF 文件' : '上传 PDF 文件';
  $('upload-description').textContent = hasFile ? '选择另一份文件重新签署' : '点击选择，或拖入文件';
  $('file-info').textContent = hasFile ? `${state.pdf.numPages} 页 · ${fileSize(state.fileSize)}` : '';
  $('document-name').textContent = hasFile ? state.name : '文档预览';
  $('document-name').title = state.name;
  $('document-badge').textContent = hasFile ? 'PDF' : '等待上传';
  $('file-status').textContent = hasFile ? '已就绪' : '准备一份 PDF';
  $('signature-status').textContent = state.signature ? '已就绪' : '用你的笔迹';
  $('step-one').classList.toggle('complete', hasFile);
  $('step-two').classList.toggle('complete', !!state.signature);
  $('step-three').classList.toggle('complete', state.placements.length > 0);
  $('create-signature').hidden = !!state.signature;
  $('saved-signature').hidden = !state.signature;
  if (state.signature) $('signature-image').src = state.signature.dataUrl;
  $('download-button').disabled = !state.placements.length || !hasFile || locked;
  $('place-button').disabled = !hasFile || locked;
  $('previous-page').disabled = !hasFile || state.page <= 1 || locked;
  $('next-page').disabled = !hasFile || state.page >= state.pdf.numPages || locked;
  $('zoom-in').disabled = !hasFile || state.zoom >= 2.5 || locked;
  $('zoom-out').disabled = !hasFile || state.zoom <= .5 || locked;
  $('zoom-fit').disabled = !hasFile || locked;
  $('zoom-fit').textContent = state.zoom === 1 ? '适合宽度' : `${Math.round(state.zoom * 100)}%`;
  $('page-counter').textContent = hasFile ? `${state.page} / ${state.pdf.numPages}` : '— / —';
  for (const id of ['upload-button', 'replace-button', 'empty-upload', 'sample-button', 'create-signature', 'redraw-button']) $(id).disabled = locked;
  $('file-input').disabled = locked;
  $('export-mode').disabled = locked;
  $('export-description').textContent = state.placements.length ? `已放置 ${state.placements.length} 个签名，确认后即可下载。` : '确认签名位置后，保存你的文件。';
  $('workspace-hint').textContent = hasFile ? (state.placements.length ? '拖动调整位置，拉动圆点缩放' : '创建签名后，点击「放到当前页」') : '签名可以自由拖动，放在你想要的位置';
  $('selection-toolbar').hidden = !state.selected || locked;
}

async function getPage(number) {
  if (!state.pages.has(number)) state.pages.set(number, await state.pdf.getPage(number));
  return state.pages.get(number);
}

async function renderPage() {
  if (!state.pdf) return;
  const generation = ++state.generation;
  state.rendering = true;
  state.renderTask?.cancel();
  updateUI(); loading(true, '正在渲染页面…');
  try {
    const page = await getPage(state.page);
    if (generation !== state.generation) return;
    const base = page.getViewport({ scale: 1 });
    const padding = window.innerWidth <= 760 ? 24 : 52;
    const available = Math.max(200, Math.min(960, $('document-scroll').clientWidth - padding));
    const viewport = page.getViewport({ scale: available / base.width * state.zoom });
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(12000000 / (viewport.width * viewport.height)));
    const temp = document.createElement('canvas');
    temp.width = Math.ceil(viewport.width * pixelRatio);
    temp.height = Math.ceil(viewport.height * pixelRatio);
    state.renderTask = page.render({
      canvasContext: temp.getContext('2d'), viewport,
      transform: pixelRatio === 1 ? null : [pixelRatio, 0, 0, pixelRatio, 0, 0],
      background: 'rgb(255,255,255)',
    });
    await state.renderTask.promise;
    if (generation !== state.generation) return;
    const canvas = $('pdf-canvas');
    canvas.width = temp.width; canvas.height = temp.height;
    canvas.getContext('2d').drawImage(temp, 0, 0);
    $('page-sheet').style.width = `${viewport.width}px`;
    $('page-sheet').style.height = `${viewport.height}px`;
    renderPlacements();
  } catch (error) {
    if (error.name !== 'RenderingCancelledException' && generation === state.generation) {
      console.error(error); toast('这一页暂时无法预览，请尝试其他 PDF 文件。', true);
    }
  } finally {
    if (generation === state.generation) {
      state.renderTask = null; state.rendering = false;
      loading(false); updateUI();
    }
  }
}

async function openPdf(file) {
  if (state.busy || state.rendering) return;
  if (!file || !/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') return toast('请选择 PDF 格式的文件。', true);
  if (file.size > 100 * 1024 * 1024) return toast('文件超过 100 MB，请先压缩 PDF 再打开。', true);
  state.busy = true; updateUI(); loading(true);
  let candidate;
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!new TextDecoder('latin1').decode(bytes.subarray(0, 1024)).includes('%PDF-')) throw new Error('INVALID_PDF');
    // Validate that the file can be edited before replacing the current document.
    await PDFDocument.load(bytes, { updateMetadata: false });
    const task = pdfjs.getDocument({
      data: bytes.slice(),
      ...pdfAssets,
      isEvalSupported: false, enableXfa: false,
    });
    task.onPassword = () => { task.destroy(); };
    candidate = await task.promise;
    await candidate.getPage(1);
    const previous = state.pdf;
    state.generation++;
    state.pdf = candidate; state.bytes = bytes; state.name = file.name; state.fileSize = file.size;
    state.page = 1; state.zoom = 1; state.pages = new Map(); state.placements = []; state.selected = null;
    state.busy = false; updateUI();
    $('document-scroll').scrollTop = 0;
    $('document-scroll').scrollLeft = 0;
    await renderPage();
    previous?.loadingTask.destroy().catch(() => {});
    toast(state.signature ? '文件已打开，点击「放到当前页」添加签名。' : '文件已打开，接下来创建你的手写签名。');
  } catch (error) {
    if (candidate && candidate !== state.pdf) candidate.loadingTask.destroy().catch(() => {});
    console.error(error);
    const encrypted = /encrypt|password/i.test(error.message || error.name);
    toast(encrypted ? '这份 PDF 已加密，请先移除密码保护后再打开。' : '无法打开这份 PDF，文件可能已损坏或格式不受支持。', true);
  } finally {
    state.busy = false; loading(false); updateUI(); $('file-input').value = '';
  }
}

function pickFile() { if (!state.busy && !state.rendering) $('file-input').click(); }
for (const id of ['upload-button', 'empty-upload', 'replace-button']) $(id).addEventListener('click', pickFile);
$('file-input').addEventListener('change', e => openPdf(e.target.files[0]));
let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if (!event.dataTransfer.types.includes('Files')) return;
  event.preventDefault(); dragDepth++; $('workspace').classList.add('drag-over');
});
document.addEventListener('dragover', event => { if (event.dataTransfer.types.includes('Files')) event.preventDefault(); });
document.addEventListener('dragleave', event => {
  if (event.dataTransfer.types.includes('Files') && --dragDepth <= 0) { dragDepth = 0; $('workspace').classList.remove('drag-over'); }
});
document.addEventListener('drop', event => {
  if (!event.dataTransfer.files.length) return;
  event.preventDefault(); dragDepth = 0; $('workspace').classList.remove('drag-over');
  if (event.dataTransfer.files.length > 1) toast('一次处理一份 PDF，已选择第一个文件。');
  openPdf(event.dataTransfer.files[0]);
});

const pad = new SignaturePad($('signature-canvas'), count => {
  $('drawing-placeholder').hidden = count > 0;
  $('save-signature').disabled = count === 0;
  $('undo-stroke').disabled = count === 0;
  $('clear-canvas').disabled = count === 0;
});
function showSignatureDialog() {
  window.getSelection()?.removeAllRanges();
  $('signature-dialog').showModal();
  requestAnimationFrame(() => pad.resize());
}
// The toolbar labels next to the canvas must not become text-selection targets
// when a finger pauses or drifts over the edge of the writing surface.
for (const type of ['selectstart', 'contextmenu']) $('signature-dialog').addEventListener(type, event => {
  if (event.cancelable) event.preventDefault();
});
$('create-signature').addEventListener('click', showSignatureDialog);
$('redraw-button').addEventListener('click', showSignatureDialog);
$('close-signature').addEventListener('click', () => $('signature-dialog').close());
$('undo-stroke').addEventListener('click', () => pad.undo());
$('clear-canvas').addEventListener('click', () => pad.clear());
document.querySelectorAll('[name="ink-color"]').forEach(el => el.addEventListener('change', () => { pad.color = el.value; }));
$('pen-width').addEventListener('change', event => { pad.width = Number(event.target.value); });
$('save-signature').addEventListener('click', async () => {
  const signature = pad.export();
  if (!signature) return toast('请先在画布上写下签名。', true);
  state.signature = signature;
  $('signature-dialog').close(); updateUI();
  if (state.pdf) await placeSignature(); else toast('签名已就绪，选择 PDF 文件后即可放置。');
});

async function placeSignature() {
  if (!state.pdf || !state.signature || state.busy || state.rendering) return;
  const page = await getPage(state.page);
  const viewport = page.getViewport({ scale: 1 });
  let w = .3;
  let h = w * viewport.width / viewport.height * state.signature.height / state.signature.width;
  if (h > .35) { w *= .35 / h; h = .35; }
  const item = clampPlacement({
    id: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`,
    page: state.page, x: (1 - w) / 2, y: .65, w, h, signature: state.signature,
  });
  state.placements.push(item); state.selected = item.id;
  renderPlacements(); updateUI();
  if (window.innerWidth <= 760) $('workspace').scrollIntoView({ behavior: 'smooth', block: 'start' });
  const top = item.y * $('page-sheet').clientHeight + $('page-sheet').offsetTop;
  const scroll = $('document-scroll');
  if (top < scroll.scrollTop + 30 || top > scroll.scrollTop + scroll.clientHeight - 100) scroll.scrollTo({ top: Math.max(0, top - scroll.clientHeight * .5), behavior: 'smooth' });
}
$('place-button').addEventListener('click', placeSignature);
function positionNode(node, item) {
  Object.assign(node.style, { left: `${item.x * 100}%`, top: `${item.y * 100}%`, width: `${item.w * 100}%`, height: `${item.h * 100}%` });
}
function selectPlacement(id) {
  state.selected = id;
  for (const node of $('placement-layer').children) node.classList.toggle('selected', node.dataset.id === id);
  updateUI();
}
function renderPlacements() {
  const layer = $('placement-layer'); layer.replaceChildren();
  for (const item of state.placements.filter(item => item.page === state.page)) {
    const node = document.createElement('div');
    node.className = 'signature-node'; node.dataset.id = item.id; node.tabIndex = 0;
    node.role = 'button'; node.setAttribute('aria-label', '手写签名，方向键微调位置，Delete 删除');
    node.classList.toggle('selected', state.selected === item.id);
    const image = document.createElement('img'); image.src = item.signature.dataUrl; image.alt = ''; image.draggable = false;
    const handle = document.createElement('button'); handle.className = 'resize-handle'; handle.type = 'button';
    handle.setAttribute('aria-label', '拖动缩放签名'); handle.title = '拖动缩放，或用方向键调整大小'; handle.innerHTML = icon('resize');
    node.append(image, handle); positionNode(node, item); layer.append(node);
    node.addEventListener('focus', () => selectPlacement(item.id));
    node.addEventListener('pointerdown', event => {
      if (state.busy || state.rendering || event.pointerType === 'mouse' && event.button !== 0) return;
      event.preventDefault(); event.stopPropagation();
      selectPlacement(item.id); node.focus({ preventScroll: true });
      const resizing = event.target.closest('.resize-handle');
      const initial = { ...item }, startX = event.clientX, startY = event.clientY;
      const rect = $('page-sheet').getBoundingClientRect();
      node.setPointerCapture(event.pointerId); node.classList.add('dragging');
      const move = e => {
        if (e.pointerId !== event.pointerId) return;
        e.preventDefault();
        const dx = e.clientX - startX, dy = e.clientY - startY;
        if (resizing) Object.assign(item, resizePlacement(initial, dx, dy, rect.width, rect.height));
        else { item.x = clamp(initial.x + dx / rect.width, 0, 1 - item.w); item.y = clamp(initial.y + dy / rect.height, 0, 1 - item.h); }
        positionNode(node, item);
      };
      const end = e => {
        if (e.pointerId !== event.pointerId) return;
        node.classList.remove('dragging');
        node.removeEventListener('pointermove', move); node.removeEventListener('pointerup', end); node.removeEventListener('pointercancel', end); node.removeEventListener('lostpointercapture', end);
      };
      node.addEventListener('pointermove', move); node.addEventListener('pointerup', end); node.addEventListener('pointercancel', end); node.addEventListener('lostpointercapture', end);
    });
    node.addEventListener('keydown', event => {
      if (['Delete', 'Backspace'].includes(event.key)) { event.preventDefault(); deleteSelected(); return; }
      const vectors = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
      if (!vectors[event.key]) return;
      event.preventDefault(); event.stopPropagation();
      const [dx, dy] = vectors[event.key]; const rect = $('page-sheet').getBoundingClientRect(); const step = event.shiftKey ? 10 : 1;
      if (event.target === handle) Object.assign(item, resizePlacement(item, (dx + dy) * step, 0, rect.width, rect.height));
      else { item.x += dx * step / rect.width; item.y += dy * step / rect.height; clampPlacement(item); }
      positionNode(node, item);
    });
  }
}
function deleteSelected() {
  if (!state.selected) return;
  state.placements = state.placements.filter(item => item.id !== state.selected); state.selected = null;
  renderPlacements(); updateUI();
}
$('delete-button').addEventListener('click', deleteSelected);
$('deselect-button').addEventListener('click', () => { selectPlacement(null); toast('位置已确认，可继续添加签名或下载 PDF。'); });
$('duplicate-button').addEventListener('click', () => {
  const selected = state.placements.find(item => item.id === state.selected);
  if (!selected) return;
  const item = clampPlacement({ ...selected, id: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`, x: selected.x + .03, y: selected.y + .03 });
  state.placements.push(item); state.selected = item.id; renderPlacements(); updateUI();
});
$('placement-layer').addEventListener('pointerdown', event => { if (event.target === $('placement-layer')) selectPlacement(null); });

for (const [id, delta] of [['previous-page', -1], ['next-page', 1]]) $(id).addEventListener('click', async () => {
  if (state.busy || state.rendering || !state.pdf) return;
  state.page = clamp(state.page + delta, 1, state.pdf.numPages); state.selected = null;
  $('document-scroll').scrollTop = 0; await renderPage();
});
for (const [id, delta] of [['zoom-out', -.25], ['zoom-in', .25], ['zoom-fit', 0]]) $(id).addEventListener('click', () => {
  if (state.busy || state.rendering) return;
  state.zoom = delta === 0 ? 1 : clamp(state.zoom + delta, .5, 2.5); renderPage();
});
let resizeTimer, previousWidth = 0;
new ResizeObserver(entries => {
  const width = Math.round(entries[0].contentRect.width);
  if (width === previousWidth) return;
  previousWidth = width; clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (state.pdf && !state.busy) renderPage(); }, 160);
}).observe($('document-scroll'));

$('download-button').addEventListener('click', async () => {
  if (!state.pdf || !state.placements.length || state.busy || state.rendering) return;
  selectPlacement(null); state.busy = true; updateUI(); loading(true, '正在生成签名 PDF…');
  try {
    const pdf = await PDFDocument.load(state.bytes, { updateMetadata: false });
    const images = new Map();
    for (const item of state.placements) {
      if (!images.has(item.signature.id)) images.set(item.signature.id, await pdf.embedPng(item.signature.dataUrl));
      const page = await getPage(item.page);
      const { angle, ...options } = placementToPdf(item, page.getViewport({ scale: 1 }));
      pdf.getPage(item.page - 1).drawImage(images.get(item.signature.id), { ...options, rotate: degrees(angle) });
    }
    let bytes = await pdf.save();
    const flattened = $('export-mode').value === 'flattened';
    if (flattened) bytes = await flattenPdf(bytes, {
      documentOptions: pdfAssets,
      onProgress: (page, total) => loading(true, `正在合并页面 ${page} / ${total}…`),
    });
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = state.name.replace(/\.pdf$/i, '') + (flattened ? '_已签名_合并图片.pdf' : '_已签名.pdf');
    document.body.append(a); a.click(); a.remove();
    // Keep each URL alive long enough for mobile browsers to finish saving it.
    setTimeout(() => URL.revokeObjectURL(url), 120000);
    $('export-hint').textContent = '文件已生成，可以继续编辑或再次下载';
    toast('签名 PDF 已生成，请在浏览器下载列表中查看。');
  } catch (error) {
    console.error(error); toast('生成失败，可能是文件内容不受支持。请尝试另一份 PDF。', true);
  } finally { state.busy = false; loading(false); updateUI(); }
});

$('export-mode').addEventListener('change', () => {
  $('mode-note').textContent = $('export-mode').value === 'flattened'
    ? '整页变为图片，文字不可选中；仍可截图或裁剪。'
    : '文字保持可选中，签名作为独立图片嵌入。';
});

$('sample-button').addEventListener('click', async () => {
  if (state.busy || state.rendering) return;
  try {
    const pdf = await PDFDocument.create();
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const ink = rgb(.15, .29, .23), muted = rgb(.51, .57, .51), line = rgb(.87, .9, .85);
    for (let n = 0; n < 2; n++) {
      const page = pdf.addPage([595.28, 841.89]);
      const text = (str, x, y, size = 11, isBold = false, color = ink) => page.drawText(str, { x, y, size, font: isBold ? bold : font, color });
      text('QIANSHU / SAMPLE DOCUMENT', 50, 786, 9, true, muted);
      page.drawLine({ start: { x: 50, y: 768 }, end: { x: 545, y: 768 }, thickness: 1, color: line });
      text(n === 0 ? 'Good things start' : 'A little ink.', 50, 707, 34, true);
      text(n === 0 ? 'with your signature.' : 'A clear agreement.', 50, 660, 34, true);
      text(n === 0 ? 'A simple space to try your first digital handwritten signature.' : 'Try placing the same signature on another page.', 50, 622, 11, false, muted);
      text(n === 0 ? 'SERVICE AGREEMENT' : 'CONFIRMATION', 50, 551, 11, true);
      const lines = n === 0 ? [
        'This sample is here to help you get comfortable with signing a PDF.',
        'Write your name on the signature canvas, then place it on this page.',
        'Move the signature into position and adjust its size using the handle.',
        'When everything looks right, download your signed document.',
      ] : [
        'Your signature can be used on more than one page.',
        'Choose a page using the arrows below the document preview.',
        'Add another signature, move it into place, and save when ready.',
        'The text and pages of the original PDF remain in your download.',
      ];
      lines.forEach((str, i) => text(str, 50, 514 - i * 25, 11, false, muted));
      page.drawRectangle({ x: 50, y: 274, width: 495, height: 88, color: rgb(.965, .976, .953) });
      text('YOUR FILE. YOUR SIGNATURE.', 68, 336, 10, true);
      text('Processed locally in your browser. No upload required.', 68, 311, 10, false, muted);
      page.drawLine({ start: { x: 50, y: 163 }, end: { x: 300, y: 163 }, thickness: 1, color: line });
      text('Signature', 50, 141, 10, false, muted);
      text('Date: __________________', 365, 174, 10, false, muted);
      page.drawLine({ start: { x: 50, y: 66 }, end: { x: 545, y: 66 }, thickness: 1, color: line });
      text('Created for a simpler signing experience.', 50, 45, 8, false, muted);
      text(`SAMPLE  /  ${n + 1} OF 2`, 458, 45, 8, false, muted);
    }
    await openPdf(new File([await pdf.save()], '签署体验.pdf', { type: 'application/pdf' }));
  } catch (error) { console.error(error); toast('示例文件暂时无法打开，请上传你的 PDF。', true); }
});

$('help-button').addEventListener('click', () => $('help-dialog').showModal());
for (const id of ['close-help', 'help-done']) $(id).addEventListener('click', () => $('help-dialog').close());
for (const dialog of document.querySelectorAll('dialog')) dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
});
window.addEventListener('beforeunload', event => { if (state.placements.length) { event.preventDefault(); event.returnValue = ''; } });
updateUI();
