import './toolbox.css';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import workerUrl from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url';
import { hydrateIcons, icon } from './icons.js';
import { convertPdfBatch, parsePageRange, MAX_BATCH_PAGES } from './pdf-images.js';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
hydrateIcons();
const $ = id => document.getElementById(id);
const assetBase = new URL('../pdf-assets/', document.baseURI).href;
const documentOptions = { cMapUrl: `${assetBase}cmaps/`, cMapPacked: true, standardFontDataUrl: `${assetBase}standard_fonts/`, wasmUrl: `${assetBase}wasm/`, isEvalSupported: false };
const state = { entries: [], busy: false, controller: null, urls: [], result: null, nextId: 1 };
const sizeText = bytes => bytes < 1048576 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1048576).toFixed(1)} MB`;
function message(text = '', error = false) {
  $('batch-message').hidden = !text;
  $('batch-message').textContent = text;
  $('batch-message').classList.toggle('error', error);
}
function clearResult() {
  state.urls.forEach(url => URL.revokeObjectURL(url)); state.urls = []; state.result = null;
  $('convert-results').hidden = true; $('result-previews').replaceChildren();
  $('download-zip').removeAttribute('href');
}
function plan() {
  let total = 0, invalid = false;
  for (const entry of state.entries) {
    if (entry.error) continue;
    try { entry.pages = parsePageRange(entry.range, entry.count); entry.rangeError = ''; total += entry.pages.length; }
    catch (error) { entry.rangeError = error.message; invalid = true; }
  }
  return { total, invalid };
}
function updateControls() {
  const { total, invalid } = plan();
  const ready = state.entries.filter(entry => !entry.error).length;
  $('page-estimate').textContent = `${total} 张图片`;
  $('convert-button').disabled = state.busy || !total || invalid || total > MAX_BATCH_PAGES;
  $('convert-label').textContent = state.busy ? '处理中…' : total ? `转换 ${total} 页` : '开始转换';
  $('choose-files').disabled = state.busy;
  $('sample-files').disabled = state.busy;
  $('clear-files').disabled = state.busy || !state.entries.length;
  $('cancel-convert').hidden = !state.busy;
  $('image-dpi').disabled = state.busy;
  document.querySelectorAll('input[name="format"]').forEach(input => { input.disabled = state.busy; });
  $('queue-empty').hidden = !!state.entries.length;
  const summary = $('queue-summary').firstElementChild;
  summary.textContent = state.entries.length ? `${state.entries.length} 份文件 · ${ready} 份就绪 · ${total} 页待转换` : '还没有添加文件';
  if (total > MAX_BATCH_PAGES) summary.textContent += ' · 超出 500 页，请缩小页码范围';
  for (const row of $('file-queue').children) {
    const entry = state.entries.find(item => item.id === Number(row.dataset.id));
    const input = row.querySelector('input');
    input.disabled = state.busy || !!entry.error;
    input.setAttribute('aria-invalid', String(!!entry.rangeError));
    row.querySelector('button').disabled = state.busy;
    const error = row.querySelector('.file-error');
    error.textContent = entry.error || entry.rangeError || '';
    error.hidden = !error.textContent;
  }
}
function renderQueue() {
  $('file-queue').replaceChildren();
  for (const entry of state.entries) {
    const row = document.createElement('li'); row.className = 'file-row'; row.dataset.id = entry.id;
    row.innerHTML = `<div class="file-row-top"><span class="file-icon">${icon('file')}</span><div class="file-meta"><strong></strong><span></span></div><button class="icon-button" type="button">${icon('close')}</button></div><label class="range-label">转换页码<input type="text" inputmode="text" autocomplete="off" placeholder="全部页；或 1, 3-5" spellcheck="false" /></label><p class="file-error" hidden></p>`;
    row.querySelector('strong').textContent = entry.file.name;
    row.querySelector('strong').title = entry.file.name;
    row.querySelector('.file-meta>span').textContent = `${entry.count ? `${entry.count} 页 · ` : ''}${sizeText(entry.file.size)}${entry.error ? ' · 无法处理' : ' · 已就绪'}`;
    const input = row.querySelector('input'); input.value = entry.range;
    input.id = `range-${entry.id}`;
    const error = row.querySelector('.file-error'); error.id = `error-${entry.id}`; input.setAttribute('aria-describedby', error.id);
    input.addEventListener('input', () => { entry.range = input.value; clearResult(); message(); updateControls(); });
    const remove = row.querySelector('button'); remove.setAttribute('aria-label', `移除 ${entry.file.name}`);
    remove.addEventListener('click', () => { state.entries = state.entries.filter(item => item.id !== entry.id); clearResult(); message(); renderQueue(); });
    $('file-queue').append(row);
  }
  updateControls();
}
function friendlyError(error) {
  if (error?.name === 'PasswordException') return '文件有密码保护，请解除保护后重新添加';
  if (error?.name === 'InvalidPDFException') return '不是可读取的 PDF，文件可能已损坏';
  return error?.message || '无法处理文件，请换一份 PDF 重试';
}
async function addFiles(files) {
  if (state.busy || !files.length) return;
  clearResult(); message();
  state.busy = true; state.controller = new AbortController(); updateControls();
  const signal = state.controller.signal;
  const notices = [];
  try {
    for (const file of files) {
      if (signal.aborted) break;
      if (state.entries.length >= 20) { notices.push('每批最多 20 份文件，其余文件未添加'); break; }
      if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') { notices.push(`${file.name}：请选择 PDF 文件`); continue; }
      if (file.size > 100 * 1048576 || file.size === 0) { notices.push(`${file.name}：文件需大于 0 且不超过 100 MB`); continue; }
      if (state.entries.reduce((sum, entry) => sum + entry.file.size, 0) + file.size > 200 * 1048576) { notices.push(`${file.name}：文件合计超过 200 MB，未添加`); continue; }
      if (state.entries.some(entry => entry.file.name === file.name && entry.file.size === file.size && entry.file.lastModified === file.lastModified)) { notices.push(`${file.name}：已在列表中`); continue; }
      message(`正在读取：${file.name}`);
      const entry = { id: state.nextId++, file, count: 0, range: '', pages: [], error: '' };
      let task;
      const cancel = () => { if (task) void task.destroy().catch(() => {}); };
      try {
        const data = new Uint8Array(await file.arrayBuffer());
        if (signal.aborted) break;
        task = pdfjs.getDocument({ ...documentOptions, data });
        signal.addEventListener('abort', cancel, { once: true });
        const pdf = await task.promise; entry.count = pdf.numPages;
      } catch (error) { if (signal.aborted) break; entry.error = friendlyError(error); }
      finally { signal.removeEventListener('abort', cancel); if (task) await task.destroy(); }
      state.entries.push(entry); renderQueue();
    }
    const errors = state.entries.filter(entry => entry.error).length;
    if (errors) notices.push(`${errors} 份文件无法处理；转换将仅处理标为「已就绪」的文件`);
    if (signal.aborted) notices.push('已停止读取，之前添加的文件已保留');
    message(notices.join('；'), !!errors || notices.length > 0);
  } finally {
    state.busy = false; state.controller = null;
    $('cancel-convert').disabled = false; $('cancel-convert').textContent = '取消处理'; renderQueue();
  }
}

$('choose-files').addEventListener('click', () => $('batch-input').click());
$('batch-input').addEventListener('change', event => { const files = [...event.target.files]; event.target.value = ''; void addFiles(files); });
$('clear-files').addEventListener('click', () => { state.entries = []; clearResult(); message(); renderQueue(); });
for (const event of ['dragenter', 'dragover', 'dragleave', 'drop']) $('choose-files').addEventListener(event, e => {
  e.preventDefault();
  $('choose-files').classList.toggle('drag-over', !state.busy && ['dragenter', 'dragover'].includes(event));
  if (event === 'drop') void addFiles([...e.dataTransfer.files]);
});
window.addEventListener('dragover', event => event.preventDefault());
window.addEventListener('drop', event => event.preventDefault());
$('image-dpi').addEventListener('change', () => {
  const dpi = Number($('image-dpi').value);
  $('dpi-hint').textContent = `A4 页面约 ${Math.floor(595.28 * dpi / 72)} × ${Math.floor(841.89 * dpi / 72)} 像素。清晰度越高，图片越大。`;
  clearResult();
});
document.querySelectorAll('input[name="format"]').forEach(input => input.addEventListener('change', clearResult));
$('cancel-convert').addEventListener('click', () => {
  state.controller?.abort(); $('cancel-convert').disabled = true; $('cancel-convert').textContent = '正在停止…';
});
$('convert-button').addEventListener('click', async () => {
  const { total, invalid } = plan();
  if (state.busy || !total || invalid || total > MAX_BATCH_PAGES) return;
  clearResult(); message();
  state.busy = true; state.controller = new AbortController(); updateControls();
  const signal = state.controller.signal;
  $('convert-progress').hidden = false; $('batch-progress').value = 0;
  $('convert-progress').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  let previews = 0, currentFile = '';
  try {
    const result = await convertPdfBatch(state.entries.filter(entry => !entry.error).map(entry => ({ name: entry.file.name, pages: entry.pages, read: async () => new Uint8Array(await entry.file.arrayBuffer()) })), {
      format: document.querySelector('input[name="format"]:checked').value,
      dpi: Number($('image-dpi').value), documentOptions, signal,
      onProgress({ done, total, file, page, stage }) {
        currentFile = file;
        $('progress-title').textContent = done === total ? '正在完成打包…' : '正在转换…';
        $('progress-detail').textContent = stage === 'opening' ? `正在打开 ${file}` : `${file} · 第 ${page} 页`;
        $('progress-count').textContent = `${done} / ${total}`;
        $('batch-progress').value = done / total * 100;
      },
      onImage(image) {
        if (previews++ >= 6) return;
        const url = URL.createObjectURL(new Blob([image.bytes], { type: image.mime })); state.urls.push(url);
        const card = document.createElement('a'); card.className = 'preview-card'; card.href = url; card.download = image.path.split('/').pop();
        const img = document.createElement('img'); img.src = url; img.alt = `${image.file} 第 ${image.number} 页`; img.loading = 'lazy';
        const label = document.createElement('strong'); label.textContent = `${image.file} · ${image.number}`; label.title = label.textContent;
        const size = document.createElement('span'); size.textContent = `${image.width} × ${image.height} · 点击下载单张`;
        card.append(img, label, size); $('result-previews').append(card);
      },
    });
    state.result = result;
    const url = URL.createObjectURL(result.blob); state.urls.push(url);
    const date = new Date(), pad = n => String(n).padStart(2, '0');
    $('download-zip').href = url;
    $('download-zip').download = `PDF转图片_${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}.zip`;
    $('results-summary').textContent = `${result.documents.length} 份 PDF · ${result.count} 张图片 · ${sizeText(result.bytes)}`;
    $('limited-note').hidden = !result.documents.some(entry => entry.limitedPages);
    $('convert-results').hidden = false;
    $('convert-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    clearResult();
    message(signal.aborted ? '已取消，未生成下载包。可以调整设置后重新转换。' : `${currentFile ? `${currentFile}：` : ''}${friendlyError(error)}`, !signal.aborted);
    $('batch-message').scrollIntoView({ behavior: 'smooth', block: 'center' });
  } finally {
    state.busy = false; state.controller = null;
    $('convert-progress').hidden = true; $('cancel-convert').disabled = false; $('cancel-convert').textContent = '取消处理'; updateControls();
  }
});
$('sample-files').addEventListener('click', async () => {
  if (state.busy) return;
  $('sample-files').disabled = true;
  try {
    const { PDFDocument, StandardFonts, rgb, degrees } = await import('pdf-lib');
    const files = [];
    for (const [index, name] of ['示例文档.pdf', '横向示例.pdf'].entries()) {
      const pdf = await PDFDocument.create(); const font = await pdf.embedFont(StandardFonts.Helvetica);
      for (let number = 1; number <= (index ? 1 : 3); number++) {
        const page = pdf.addPage([595, 842]);
        if (index) page.setRotation(degrees(90));
        page.drawRectangle({ x: 0, y: 0, width: 595, height: 842, color: rgb(.97, .98, .96) });
        page.drawText('A LITTLE TOOLBOX', { x: 52, y: 760, font, size: 12, color: rgb(.14, .36, .28) });
        page.drawText(`A fresh perspective.`, { x: 52, y: 655, font, size: 34, color: rgb(.1, .27, .2) });
        page.drawText(`Sample ${index + 1} / Page ${number}`, { x: 52, y: 605, font, size: 16 });
        for (let line = 0; line < 7; line++) page.drawRectangle({ x: 52, y: 500 - line * 32, width: 490 - (line % 3) * 50, height: 6, color: rgb(.79, .84, .77) });
        page.drawText('PDF TO IMAGES / LOCAL BY DESIGN', { x: 52, y: 60, font, size: 10, color: rgb(.4, .5, .42) });
      }
      files.push(new File([await pdf.save()], name, { type: 'application/pdf', lastModified: 1 }));
    }
    await addFiles(files);
  } catch (error) { message(friendlyError(error), true); }
  finally { updateControls(); }
});
window.addEventListener('beforeunload', event => { if (state.busy || state.result) { event.preventDefault(); event.returnValue = ''; } });
renderQueue();
