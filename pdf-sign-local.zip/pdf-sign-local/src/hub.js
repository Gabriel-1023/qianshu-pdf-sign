import './toolbox.css';
import { hydrateIcons } from './icons.js';
hydrateIcons();
