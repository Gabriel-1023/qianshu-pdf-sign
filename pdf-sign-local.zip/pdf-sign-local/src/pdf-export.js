import { PDFDocument } from 'pdf-lib';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';

// Render the signed pages as a whole before embedding them in a fresh PDF.
// The final file contains a single opaque page image per page, with no signature asset.
export async function flattenPdf(bytes, { documentOptions = {}, onProgress = () => {}, createCanvas = () => document.createElement('canvas'), encodeCanvas } = {}) {
  const task = getDocument({ ...documentOptions, data: bytes.slice(), isEvalSupported: false });
  try {
    const source = await task.promise;
    const result = await PDFDocument.create();
    for (let n = 1; n <= source.numPages; n++) {
      onProgress(n, source.numPages);
      const page = await source.getPage(n);
      const size = page.getViewport({ scale: 1 });
      const scale = Math.min(2, Math.sqrt(6000000 / (size.width * size.height)));
      const viewport = page.getViewport({ scale });
      const canvas = createCanvas();
      canvas.width = Math.ceil(viewport.width); canvas.height = Math.ceil(viewport.height);
      try {
        await page.render({ canvasContext: canvas.getContext('2d'), viewport, background: 'rgb(255,255,255)' }).promise;
        const imageBytes = encodeCanvas ? await encodeCanvas(canvas) : new Uint8Array(await (await new Promise((resolve, reject) => {
          canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('IMAGE_ENCODING_FAILED')), 'image/jpeg', .96);
        })).arrayBuffer());
        const image = await result.embedJpg(imageBytes);
        const output = result.addPage([size.width, size.height]);
        output.drawImage(image, { x: 0, y: 0, width: size.width, height: size.height });
      } finally { canvas.width = 1; canvas.height = 1; page.cleanup(); }
    }
    return await result.save();
  } finally { await task.destroy(); }
}
