import './toolbox.css';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { icon, hydrateIcons } from './icons.js';
import { mergePdfFiles, moveItem, pdfFilename, MAX_MERGE_PAGES } from './pdf-merge.js';

hydrateIcons();
const $ = id => document.getElementById(id);
const state = { entries: [], busy: false, id: 1, controller: null, resultUrl: null, drag: null };
const sizeText = bytes => bytes < 1048576 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1048576).toFixed(1)} MB`;
function message(text = '', error = false) { $('merge-message').hidden = !text; $('merge-message').textContent = text; $('merge-message').classList.toggle('error', error); }
function clearResult() { if (state.resultUrl) URL.revokeObjectURL(state.resultUrl); state.resultUrl = null; $('merge-result').hidden = true; $('merge-download').removeAttribute('href'); }
function controls() {
  const count = state.entries.reduce((sum, entry) => sum + entry.count, 0);
  $('merge-summary').textContent = state.entries.length ? `${state.entries.length} 份文件 · ${count} 页 · ${sizeText(state.entries.reduce((sum, entry) => sum + entry.file.size, 0))}` : '还没有添加文件';
  $('merge-empty').hidden = !!state.entries.length;
  $('merge-file-count').firstChild.textContent = `${state.entries.length} `;
  $('merge-page-count').firstChild.textContent = `${count} `;
  $('merge-start').disabled = state.busy || state.entries.length < 2 || count > MAX_MERGE_PAGES;
  for (const id of ['merge-choose', 'merge-sample', 'merge-name']) $(id).disabled = state.busy;
  $('merge-clear').disabled = state.busy || !state.entries.length;
  $('merge-cancel').hidden = !state.busy;
  if (count > MAX_MERGE_PAGES) message('页数超过 1000 页，请减少文件后再合并', true);
}
function reorder(from, to, focus = false) {
  if (state.busy || from === to || to < 0 || to >= state.entries.length) return;
  const entry = state.entries[from]; state.entries = moveItem(state.entries, from, to); clearResult(); render();
  $('sort-announcement').textContent = `${entry.file.name} 已移到第 ${to + 1} 位`;
  if (focus) $('merge-queue').children[to]?.querySelector('.drag-handle')?.focus();
}
function endDrag(event) {
  const drag = state.drag; if (!drag || (event && event.pointerId !== drag.pointer)) return;
  state.drag = null; cancelAnimationFrame(drag.frame); drag.row.classList.remove('is-dragging');
  if (drag.row.hasPointerCapture?.(drag.pointer)) drag.row.releasePointerCapture(drag.pointer);
  $('merge-queue').querySelectorAll('.drop-before,.drop-after').forEach(row => row.classList.remove('drop-before', 'drop-after'));
  document.body.classList.remove('sorting');
  if (event?.type === 'pointerup' && drag.target !== drag.from) reorder(drag.from, drag.target, true);
}
function updateDrag(event) {
  const drag = state.drag; if (!drag || event.pointerId !== drag.pointer) return;
  drag.y = event.clientY; event.preventDefault();
  const rows = [...$('merge-queue').children];
  const candidates = rows.map((row, i) => ({ row, i, rect: row.getBoundingClientRect() }));
  const hovered = candidates.find(({ rect }) => event.clientY >= rect.top && event.clientY <= rect.bottom);
  if (hovered) drag.target = hovered.i;
  else if (event.clientY < candidates[0].rect.top) drag.target = 0;
  else if (event.clientY > candidates.at(-1).rect.bottom) drag.target = rows.length - 1;
  rows.forEach((row, i) => { row.classList.toggle('drop-before', i === drag.target && drag.target < drag.from); row.classList.toggle('drop-after', i === drag.target && drag.target > drag.from); });
}
function startDrag(event, index, row) {
  if (state.busy || state.entries.length < 2 || !event.isPrimary || event.button !== 0) return;
  event.preventDefault();
  row.setPointerCapture(event.pointerId);
  state.drag = { from: index, target: index, pointer: event.pointerId, row, y: event.clientY, frame: 0 };
  row.classList.add('is-dragging'); document.body.classList.add('sorting');
  row.addEventListener('pointermove', updateDrag); row.addEventListener('pointerup', endDrag); row.addEventListener('pointercancel', endDrag);
  const scroll = () => {
    if (!state.drag) return;
    const y = state.drag.y, speed = y < 100 ? -12 : y > window.innerHeight - 100 ? 12 : 0;
    if (speed) { window.scrollBy(0, speed); updateDrag({ pointerId: state.drag.pointer, clientY: y, preventDefault() {} }); }
    state.drag.frame = requestAnimationFrame(scroll);
  };
  state.drag.frame = requestAnimationFrame(scroll);
}
function render() {
  $('merge-queue').replaceChildren();
  state.entries.forEach((entry, index) => {
    const row = document.createElement('li'); row.className = 'merge-row';
    row.innerHTML = `<button type="button" class="drag-handle">${icon('grip')}</button><span class="order-number"></span><div class="file-meta"><strong></strong><span></span></div><div class="order-buttons"><button class="icon-button up" type="button">${icon('arrow-up')}</button><button class="icon-button down" type="button">${icon('arrow-down')}</button><button class="icon-button remove" type="button">${icon('close')}</button></div>`;
    row.querySelector('.order-number').textContent = String(index + 1).padStart(2, '0');
    row.querySelector('strong').textContent = entry.file.name; row.querySelector('strong').title = entry.file.name;
    row.querySelector('.file-meta>span').textContent = `${entry.count} 页 · ${sizeText(entry.file.size)}${entry.forms ? ' · 表单将固化' : ''}`;
    const handle = row.querySelector('.drag-handle'); handle.setAttribute('aria-label', `拖动排序 ${entry.file.name}，当前第 ${index + 1} 位，可用上下方向键调整`);
    handle.disabled = state.busy;
    handle.addEventListener('pointerdown', event => startDrag(event, index, row));
    handle.addEventListener('contextmenu', event => event.preventDefault());
    handle.addEventListener('keydown', event => { if (['ArrowUp', 'ArrowDown'].includes(event.key)) { event.preventDefault(); reorder(index, index + (event.key === 'ArrowUp' ? -1 : 1), true); } });
    for (const [name, delta, label] of [['up', -1, '上移'], ['down', 1, '下移']]) {
      const button = row.querySelector(`.${name}`); button.setAttribute('aria-label', `${label} ${entry.file.name}`); button.disabled = state.busy || index + delta < 0 || index + delta >= state.entries.length;
      button.addEventListener('click', () => reorder(index, index + delta, true));
    }
    const remove = row.querySelector('.remove'); remove.setAttribute('aria-label', `移除 ${entry.file.name}`); remove.disabled = state.busy;
    remove.addEventListener('click', () => { state.entries = state.entries.filter(item => item.id !== entry.id); clearResult(); message(); render(); });
    $('merge-queue').append(row);
  });
  controls();
}
async function addFiles(files) {
  if (state.busy || !files.length) return;
  clearResult(); message(); state.busy = true; state.controller = new AbortController(); render();
  const signal = state.controller.signal, errors = [];
  try {
    for (const file of files) {
      if (signal.aborted) break;
      if (state.entries.length >= 30) { errors.push('每批最多 30 份，其余文件未添加'); break; }
      if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') { errors.push(`${file.name}：请选择 PDF`); continue; }
      if (!file.size || file.size > 100 * 1048576) { errors.push(`${file.name}：文件需大于 0 且不超过 100 MB`); continue; }
      if (state.entries.reduce((sum, entry) => sum + entry.file.size, 0) + file.size > 200 * 1048576) { errors.push(`${file.name}：合计超过 200 MB，未添加`); continue; }
      message(`正在读取：${file.name}`);
      try {
        const pdf = await PDFDocument.load(await file.arrayBuffer(), { updateMetadata: false });
        if (signal.aborted) break;
        state.entries.push({ id: state.id++, file, count: pdf.getPageCount(), forms: pdf.getForm().getFields().length > 0 });
      } catch (error) { errors.push(`${file.name}：${/encrypt/i.test(error.message) ? '带密码保护，请解除后添加' : '无法读取，文件可能损坏或格式不受支持'}`); }
      render();
    }
    if (signal.aborted) errors.push('已停止读取，之前添加的文件已保留');
    message(errors.join('；'), errors.length > 0);
  } finally { state.busy = false; state.controller = null; $('merge-cancel').disabled = false; $('merge-cancel').textContent = '取消处理'; render(); }
}
$('merge-choose').addEventListener('click', () => $('merge-input').click());
$('merge-input').addEventListener('change', event => { const files = [...event.target.files]; event.target.value = ''; void addFiles(files); });
$('merge-clear').addEventListener('click', () => { clearResult(); state.entries = []; message(); render(); });
$('merge-name').addEventListener('input', () => { if (state.resultUrl) $('merge-download').download = pdfFilename($('merge-name').value); });
for (const name of ['dragenter', 'dragover', 'dragleave', 'drop']) $('merge-choose').addEventListener(name, event => {
  event.preventDefault(); $('merge-choose').classList.toggle('drag-over', !state.busy && ['dragenter', 'dragover'].includes(name));
  if (name === 'drop') void addFiles([...event.dataTransfer.files]);
});
window.addEventListener('dragover', event => event.preventDefault()); window.addEventListener('drop', event => event.preventDefault());
window.addEventListener('keydown', event => { if (event.key === 'Escape') endDrag(); });
window.addEventListener('blur', () => endDrag());
$('merge-cancel').addEventListener('click', () => { state.controller?.abort(); $('merge-cancel').disabled = true; $('merge-cancel').textContent = '正在停止…'; });
$('merge-start').addEventListener('click', async () => {
  if (state.busy || state.entries.length < 2) return;
  clearResult(); message(); state.busy = true; state.controller = new AbortController(); render();
  const signal = state.controller.signal;
  $('merge-progress-panel').hidden = false;
  try {
    const result = await mergePdfFiles(state.entries.map(entry => ({ name: entry.file.name, count: entry.count, read: () => entry.file.arrayBuffer() })), {
      signal, onProgress({ done, total, file, stage }) {
        $('merge-progress-title').textContent = stage === 'saving' ? '正在生成 PDF…' : '正在合并…';
        $('merge-progress-detail').textContent = file;
        $('merge-progress-count').textContent = `${done} / ${total} 页`;
        $('merge-progress').value = done / total * 100;
      },
    });
    state.resultUrl = URL.createObjectURL(new Blob([result.bytes], { type: 'application/pdf' }));
    $('merge-download').href = state.resultUrl; $('merge-download').download = pdfFilename($('merge-name').value);
    $('merge-result-summary').textContent = `${state.entries.length} 份 PDF · ${result.count} 页 · ${sizeText(result.bytes.byteLength)}`;
    $('merge-result').hidden = false; $('merge-result').scrollIntoView({ behavior: 'smooth', block: 'center' });
  } catch (error) { clearResult(); message(signal.aborted ? '已取消合并，可以调整后重试。' : `合并失败：${error.message}`, !signal.aborted); }
  finally { state.busy = false; state.controller = null; $('merge-progress-panel').hidden = true; $('merge-cancel').disabled = false; $('merge-cancel').textContent = '取消处理'; render(); }
});
$('merge-sample').addEventListener('click', async () => {
  if (state.busy) return;
  const files = [];
  for (const [index, name] of ['01_封面.pdf', '02_正文.pdf', '03_附件.pdf'].entries()) {
    const pdf = await PDFDocument.create(); const font = await pdf.embedFont(StandardFonts.Helvetica);
    for (let number = 1; number <= (index === 1 ? 2 : 1); number++) {
      const page = pdf.addPage(index === 2 ? [842, 595] : [595, 842]);
      page.drawText(`DOCUMENT ${index + 1}`, { x: 50, y: page.getHeight() - 80, font, size: 30, color: rgb(.14, .36, .28) });
      page.drawText(`Page ${number} / Merge in your own order.`, { x: 50, y: page.getHeight() - 125, font, size: 15 });
    }
    files.push(new File([await pdf.save()], name, { type: 'application/pdf' }));
  }
  await addFiles(files);
});
window.addEventListener('beforeunload', event => { if (state.busy || state.resultUrl) { event.preventDefault(); event.returnValue = ''; } });
render();
