import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { Zip, ZipPassThrough } from 'fflate';

export const MAX_OUTPUT_BYTES = 128 * 1024 * 1024;
export const MAX_BATCH_PAGES = 500;

export function parsePageRange(value, count) {
  const text = value.trim().replaceAll('，', ',').replaceAll('－', '-');
  if (!text) return Array.from({ length: count }, (_, i) => i + 1);
  const pages = new Set();
  for (const part of text.split(',')) {
    const match = part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) throw new Error('页码格式应为 1, 3-5，留空表示全部');
    const first = Number(match[1]), last = Number(match[2] ?? match[1]);
    if (!Number.isSafeInteger(first) || first < 1 || last < first || last > count) {
      throw new Error(`页码必须在 1–${count} 之间，范围从小到大填写`);
    }
    for (let n = first; n <= last; n++) pages.add(n);
  }
  return [...pages].sort((a, b) => a - b);
}

export function imageViewport(page, dpi, maxPixels = 12000000, maxSide = 8192) {
  const base = page.getViewport({ scale: 1 });
  if (!(base.width > 0 && base.height > 0 && Number.isFinite(base.width * base.height))) throw new Error('PDF 页面尺寸无效');
  const wanted = dpi / 72;
  const scale = Math.min(wanted, Math.sqrt(maxPixels / (base.width * base.height)), maxSide / Math.max(base.width, base.height));
  const viewport = page.getViewport({ scale });
  return { viewport, width: Math.max(1, Math.floor(viewport.width)), height: Math.max(1, Math.floor(viewport.height)), limited: scale < wanted - 0.00001 };
}

export function archiveFolder(name, index) {
  const safe = name.replace(/\.pdf$/i, '').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g, '_').replace(/^[. ]+|[. ]+$/g, '').slice(0, 100).trim() || 'PDF';
  return `${String(index + 1).padStart(2, '0')}_${safe}`;
}

function checkAbort(signal) { if (signal?.aborted) throw new DOMException('已取消转换', 'AbortError'); }
export async function renderPageImage(page, {
  format = 'png', dpi = 150, signal,
  createCanvas = () => document.createElement('canvas'), encodeCanvas,
} = {}) {
  if (!['png', 'jpeg'].includes(format) || ![72, 150, 200, 300].includes(dpi)) throw new Error('不支持的图片格式或清晰度');
  checkAbort(signal);
  const { viewport, width, height, limited } = imageViewport(page, dpi);
  const canvas = createCanvas();
  canvas.width = width; canvas.height = height;
  let render;
  const cancel = () => render?.cancel();
  signal?.addEventListener('abort', cancel, { once: true });
  try {
    render = page.render({ canvasContext: canvas.getContext('2d'), viewport, background: 'rgb(255,255,255)' });
    await render.promise;
    checkAbort(signal);
    const mime = `image/${format}`;
    const bytes = encodeCanvas ? await encodeCanvas(canvas, mime) : new Uint8Array(await (await new Promise((resolve, reject) => {
      canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('图片编码失败，请降低清晰度后重试')), mime, .92);
    })).arrayBuffer());
    checkAbort(signal);
    return { bytes, width, height, limited, mime };
  } finally {
    signal?.removeEventListener('abort', cancel);
    canvas.width = 1; canvas.height = 1; page.cleanup();
  }
}

// One canvas and one PDF at a time. Images are stored without redundant ZIP compression.
export async function convertPdfBatch(entries, {
  format = 'png', dpi = 150, documentOptions = {}, signal,
  onProgress = () => {}, onImage = () => {}, createCanvas, encodeCanvas,
  maxOutputBytes = MAX_OUTPUT_BYTES,
} = {}) {
  const total = entries.reduce((sum, entry) => sum + entry.pages.length, 0);
  if (!total || total > MAX_BATCH_PAGES) throw new Error(`每批请选择 1–${MAX_BATCH_PAGES} 页`);
  const chunks = [], documents = [];
  let zipError, outputBytes = 0, complete = false, done = 0;
  const zip = new Zip((error, data, final) => {
    if (error) { zipError = error; return; }
    outputBytes += data.length;
    if (outputBytes > maxOutputBytes) { zipError = new Error('导出结果超过 128 MB，请减少页数或选择 JPG 后分批转换'); return; }
    chunks.push(data); complete = final;
  });
  try {
    for (const [index, entry] of entries.entries()) {
      checkAbort(signal);
      onProgress({ done, total, file: entry.name, page: 0, stage: 'opening' });
      const data = await entry.read();
      checkAbort(signal);
      const task = getDocument({ ...documentOptions, data, isEvalSupported: false });
      const cancel = () => { void task.destroy().catch(() => {}); };
      signal?.addEventListener('abort', cancel, { once: true });
      let limitedPages = 0;
      try {
        const pdf = await task.promise;
        const folder = archiveFolder(entry.name, index);
        for (const number of entry.pages) {
          checkAbort(signal);
          onProgress({ done, total, file: entry.name, page: number, stage: 'rendering' });
          const page = await pdf.getPage(number);
          const image = await renderPageImage(page, { format, dpi, signal, createCanvas, encodeCanvas });
          const path = `${folder}/page-${String(number).padStart(Math.max(3, String(pdf.numPages).length), '0')}.${format === 'jpeg' ? 'jpg' : 'png'}`;
          const file = new ZipPassThrough(path);
          zip.add(file); file.push(image.bytes, true);
          if (zipError) throw zipError;
          if (image.limited) limitedPages++;
          onImage({ ...image, path, number, file: entry.name });
          done++;
          onProgress({ done, total, file: entry.name, page: number, stage: 'rendered' });
          await new Promise(resolve => setTimeout(resolve, 0));
        }
        documents.push({ name: entry.name, folder, count: entry.pages.length, limitedPages });
      } finally { signal?.removeEventListener('abort', cancel); await task.destroy(); }
    }
    checkAbort(signal);
    zip.end();
    if (zipError) throw zipError;
    if (!complete) throw new Error('ZIP 打包未完成，请重新转换');
    return { blob: new Blob(chunks, { type: 'application/zip' }), documents, count: done, bytes: outputBytes };
  } finally { zip.terminate(); }
}
